fetch('https://restcountries.com/v3.1/all')
  .then(response => response.json())
  .then(data => {
    const countries = data.map(country => country.name.common);
    console.log(countries);
  })
  .catch(error => console.log('Error:', error));