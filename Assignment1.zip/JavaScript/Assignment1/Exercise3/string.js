
var inputElement = document.getElementById('inputString');
var outputElement = document.getElementById('output');

// Function to reverse the string
function reverse() {
  var string = inputElement.value;
  var reversedString = stringModule.reverseString(string);
  outputElement.textContent = reversedString;
}

// Import the string module
var stringModule = require('./utils/string.js');
