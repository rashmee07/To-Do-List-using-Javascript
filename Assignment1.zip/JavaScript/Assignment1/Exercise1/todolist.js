// Get the necessary elements
const todoForm = document.getElementById("todo-form");
const todoInput = document.getElementById("todo-input");
const todoList = document.getElementById("todo-list");
const searchInput = document.getElementById("search-input");

// Function to create a new to-do item
function createTodoItem(text) {
    const listItem = document.createElement("li");
    listItem.classList.add("todo-item");

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    listItem.appendChild(checkbox);

    const todoText = document.createElement("span");
    todoText.classList.add("todo-text");
    todoText.innerText = text;
    listItem.appendChild(todoText);

    const deleteButton = document.createElement("button");
    deleteButton.classList.add("delete-button");
    deleteButton.innerText = "Delete";
    listItem.appendChild(deleteButton);

    return listItem;
}

// Function to handle the form submission
function handleFormSubmit(event) {
    event.preventDefault();
    const todoText = todoInput.value.trim();

    if (todoText !== "") {
        const todoItem = createTodoItem(todoText);
        todoList.appendChild(todoItem);
        todoInput.value = "";
    }
}

// Function to handle the delete button click
function handleDeleteButtonClick(event) {
    const listItem = event.target.parentElement;
    todoList.removeChild(listItem);
}

// Function to handle search input
function handleSearchInput() {
    const searchTerm = searchInput.value.toLowerCase();
    const items = todoList.getElementsByClassName("todo-item");

    for (const item of items) {
        const text = item.querySelector(".todo-text").innerText.toLowerCase();
        if (text.includes(searchTerm)) {
            item.style.display = "flex";
        } else {
            item.style.display = "none";
        }
    }
}

// Add event listeners
todoForm.addEventListener("submit", handleFormSubmit);
todoList.addEventListener("click", function (event) {
    if (event.target.matches(".delete-button")) {
        handleDeleteButtonClick(event);
    }
});
searchInput.addEventListener("input", handleSearchInput);